import os,sys,time,json,pathlib,statistics,platform,resource
sys.path.insert(0,'/repo')
res={'python':sys.version,'platform':platform.platform(),'stages':{}}
def mem():
 d={}
 for line in pathlib.Path('/proc/self/status').read_text().splitlines():
  if line.startswith(('VmRSS:','VmHWM:','Threads:')):k,v=line.split(':');d[k]=v.strip()
 for f in ['memory.current','memory.peak','memory.max','cpu.max']:
  p=pathlib.Path('/sys/fs/cgroup')/f
  if p.exists():d[f]=p.read_text().strip()
 return d
def stage(n):res['stages'][n]=mem()
stage('python')
from api.app import app
stage('api_import')
t=time.perf_counter();import torch
res['torch_import_ms']=(time.perf_counter()-t)*1000;res['torch']=torch.__version__;res['default_threads']=[torch.get_num_threads(),torch.get_num_interop_threads()]
if len(sys.argv)>1 and sys.argv[1]!='default':torch.set_num_threads(int(sys.argv[1]));torch.set_num_interop_threads(1)
res['effective_threads']=[torch.get_num_threads(),torch.get_num_interop_threads()];stage('torch_import')
from games.connect4.agents.mcts_nn_agent import Connect4Net
model=Connect4Net().eval();stage('constructed')
t=time.perf_counter(); ck=torch.load('/repo/models/connect4/connect4_model_iter_100.pt',map_location='cpu',weights_only=True);model.load_state_dict(ck['model_state_dict'],strict=True);del ck
res['load_ms']=(time.perf_counter()-t)*1000;stage('loaded')
x=torch.zeros(1,1,6,7)
with torch.inference_mode():
 t=time.perf_counter();model(x);res['cold_forward_ms']=(time.perf_counter()-t)*1000
 stage('first_forward')
 times=[]
 for i in range(300):
  t=time.perf_counter();model(x);times.append((time.perf_counter()-t)*1000)
  if i in [9,99,299]:stage(f'after_{i+1}')
res['warm_ms']={'n':len(times),'median':statistics.median(times),'p95':sorted(times)[284],'min':min(times),'max':max(times),'total':sum(times)}
print(json.dumps(res,indent=2))
