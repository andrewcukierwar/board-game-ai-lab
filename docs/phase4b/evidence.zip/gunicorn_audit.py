def post_worker_init(worker):
 import sys
 sys.path.insert(0,'/repo')
 import torch
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 from games.connect4.agents.mcts_nn_agent import Connect4Net
 model=Connect4Net().eval()
 ck=torch.load('/repo/models/connect4/connect4_model_iter_100.pt',map_location='cpu',weights_only=True)
 model.load_state_dict(ck['model_state_dict'],strict=True)
 with torch.inference_mode():model(torch.zeros(1,1,6,7))
 worker.audit_model=model
