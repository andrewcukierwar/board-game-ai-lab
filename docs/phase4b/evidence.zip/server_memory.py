import subprocess,sys,time,pathlib,json,urllib.request,os,signal
cmd=['gunicorn','api.app:app','--bind=127.0.0.1:8000','--workers=1','--threads=4','--worker-tmp-dir=/tmp']
if len(sys.argv)>1:cmd+=['--config=/audit/gunicorn_audit.py']
p=subprocess.Popen(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
try:
 for i in range(200):
  if p.poll() is not None:raise RuntimeError(p.stderr.read().decode())
  try:
   with urllib.request.urlopen('http://127.0.0.1:8000/v1/connect4/health',timeout=.25) as r:
    if r.status==200:break
  except Exception:time.sleep(.1)
 else:raise TimeoutError('server not ready')
 rows=[]
 for d in pathlib.Path('/proc').iterdir():
  if not d.name.isdigit():continue
  try:
   cmdline=(d/'cmdline').read_bytes().replace(b'\0',b' ').decode()
   if 'gunicorn' not in cmdline:continue
   fields={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in (d/'status').read_text().splitlines() if line.startswith(('VmRSS:','VmHWM:','PPid:','Threads:'))}
   rows.append({'pid':int(d.name),'cmd':cmdline,**fields})
  except (OSError,UnicodeDecodeError):pass
 print(json.dumps({'processes':rows,'cgroup':{f:(pathlib.Path('/sys/fs/cgroup')/f).read_text().strip() for f in ['memory.current','memory.peak','memory.max','cpu.max']}},indent=2))
finally:
 p.terminate()
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill();p.wait()
