import sys,json,copy,collections,numpy as np,torch
sys.path.insert(0,'/repo')
from games.connect4.connect4 import Connect4
from games.connect4.agents.mcts_nn_agent import MCTSNNAgent,Node
class Constant(torch.nn.Module):
 def forward(self,x):return torch.full((1,7),1/7),torch.tensor([[.5,0.,.5]])
def game(seq):
 g=Connect4()
 for m in seq:assert not g.is_game_over() and g.is_valid_move(m);g.make_move(m)
 return g
a=MCTSNNAgent(Constant(),simulation_limit=2,temperature=0)
g=game([]);a._store_training_example(g.board,np.ones(7)/7);g.make_move(3)
print('shallow_copy_row_shared',a.training_examples[0].board[5] is g.board[5],'saved_empty_now',a.training_examples[0].board[5][3])
for winner in [0,1,-1]:
 a.update_game_result(winner);print('winner',winner,'assigned_value',a.training_examples[0].value)
for seq in [[0,1,0,1,2,1],[0,1,0,1,0]]:
 g=game(seq);print('block_fixture',seq,'player',g.current_player,'forced_move',a._check_forced_move(g))
# Demonstrate selection maximizes child-to-move instead of parent-to-move value.
r=Node(game([]));r.visits=20
for move,q in [(0,1.),(1,-1.)]:
 g=game([move]);ch=Node(g,parent=r,move=move);ch.visits=10;ch.q_value=q;r.children[move]=ch
print('selected_child_Q',a._select_child(r)[1].q_value)
# Exercise actual bounded graph search, then inspect aliased children and parent mismatches.
g=game([]);before=copy.deepcopy(g.board);a=MCTSNNAgent(Constant(),simulation_limit=96,temperature=0);move=a.choose_move(g)
incoming=collections.defaultdict(list)
for node in a.transposition_table.values():
 for m,ch in node.children.items():incoming[id(ch)].append((node,m,ch))
shared=[edges for edges in incoming.values() if len(edges)>1]
wrong=[(n,m,ch) for edges in incoming.values() for n,m,ch in edges if ch.parent is not n]
print('bounded_search',{'budget':96,'move':int(move),'input_unchanged':g.board==before,'nodes':len(a.transposition_table),'shared_nodes':len(shared),'wrong_parent_edges':len(wrong)})
if wrong:
 n,m,ch=wrong[0];print('wrong_parent_example',{'incoming_move':m,'stored_move':ch.move,'actual_parent_board':list(n.game_state.board),'stored_parent_board':list(ch.parent.game_state.board)})
for budget,seq in [(1,[]),(2,[0,1,0,1,0,2,0])]:
 try:
  b=MCTSNNAgent(Constant(),simulation_limit=budget,temperature=0);m=b.choose_move(game(seq));print('edge',budget,seq,'returned',int(m),'policy',b.training_examples[-1].policy.tolist())
 except Exception as e:print('edge',budget,seq,'error',repr(e))
