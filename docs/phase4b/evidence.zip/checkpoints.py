import sys,json,hashlib,pathlib,platform,copy
import torch,numpy as np
sys.path.insert(0,'/repo')
from games.connect4.agents.mcts_nn_agent import Connect4Net,MCTSNNAgent
from games.connect4.connect4 import Connect4
torch.set_num_threads(1); torch.set_num_interop_threads(1)
root=pathlib.Path('/repo/models/connect4'); out={'runtime':{'python':sys.version,'torch':torch.__version__,'numpy':np.__version__,'platform':platform.platform()},'checkpoints':[]}
draw=[2,0,0,0,0,0,0,1,1,1,1,1,1,2,2,2,2,2,3,3,3,3,3,3,6,4,4,4,4,4,4,5,5,5,5,5,5,6,6,6,6,6]
seqs={'empty':[],'opening_O':[3],'opening_X':[3,2],'mid_X':draw[:18],'mid_O':draw[:19],'full_column':[3]*6,'late_X':draw[:38],'late_O':draw[:41],'terminal_draw':draw,'terminal_X':[0,1,0,1,0,2,0],'terminal_O':[0,1,0,1,2,1,2,1]}
games={}
for name,seq in seqs.items():
 g=Connect4()
 for m in seq:
  assert not g.is_game_over() and g.is_valid_move(m); assert g.make_move(m)
 games[name]=g
out['fixtures']={n:{'moves':seqs[n],'player':g.current_player,'winner':g.check_winner(),'terminal':g.is_game_over(),'legal':g.get_valid_moves(),'board':list(g.board)} for n,g in games.items()}
prev=None; vecs=[]
for p in sorted(root.glob('*.pt'),key=lambda p:int(p.stem.split('_')[-1])):
 r={'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 try:
  ck=torch.load(p,weights_only=True,map_location='cpu'); assert type(ck) is dict
  sd=ck['model_state_dict']; model=Connect4Net().cpu().eval(); expected=model.state_dict()
  assert set(sd)==set(expected)
  assert all(isinstance(v,torch.Tensor) and v.shape==expected[k].shape and v.dtype==expected[k].dtype and v.device.type=='cpu' for k,v in sd.items())
  model.load_state_dict(sd,strict=True)
  r['metadata']={k:v for k,v in ck.items() if k!='model_state_dict'}
  r['tensors']={k:{'shape':list(v.shape),'dtype':str(v.dtype),'numel':v.numel(),'finite':bool(torch.isfinite(v).all()),'nonzero':int(torch.count_nonzero(v)),'min':v.min().item(),'max':v.max().item(),'std':v.std().item()} for k,v in sd.items()}
  vec=torch.cat([v.flatten() for v in sd.values()]); vecs.append(vec)
  r.update(load='strict_pass',parameter_count=vec.numel(),all_finite=bool(torch.isfinite(vec).all()),nonzero=int(torch.count_nonzero(vec)),std=vec.std().item(),l2=vec.norm().item())
  if prev is not None:r['previous_delta']={'l2':(vec-prev).norm().item(),'max_abs':(vec-prev).abs().max().item(),'changed':int(torch.count_nonzero(vec-prev))}
  prev=vec
  a=MCTSNNAgent(model,simulation_limit=2); r['predictions']={}
  for n,g in games.items():
   t=a._get_state_tensor(g)
   with torch.inference_mode():
    pol,val=model(t); bp,bv=model(t.unsqueeze(0)); sp,sv=a._predict(g)
   r['predictions'][n]={'input_shape':list(t.shape),'policy_shape':list(pol.shape),'value_shape':list(val.shape),'policy':pol[0].tolist(),'wdl':val[0].tolist(),'scalar':float(sv),'policy_sum':float(pol.sum()),'value_sum':float(val.sum()),'batch_match':bool(torch.allclose(pol,bp) and torch.allclose(val,bv)),'finite':bool(torch.isfinite(pol).all() and torch.isfinite(val).all()),'illegal_mass':float(sum(pol[0,m] for m in range(7) if m not in g.get_valid_moves()))}
  alt=copy.deepcopy(games['opening_O']); alt.current_player=0;alt.piece='X'
  r['turn_metadata_changes_tensor']=not torch.equal(a._get_state_tensor(alt),a._get_state_tensor(games['opening_O']))
  with torch.inference_mode():
   batch=torch.stack([a._get_state_tensor(g) for g in games.values()]); bp,bv=model(batch)
  r['batch_shape']=[list(bp.shape),list(bv.shape)]
 except Exception as e:r['error']=repr(e)
 out['checkpoints'].append(r)
out['all_pairwise_weights_distinct']=all(not torch.equal(a,b) for i,a in enumerate(vecs) for b in vecs[i+1:])
pathlib.Path('/audit/checkpoints.json').write_text(json.dumps(out,indent=2))
for r in out['checkpoints']:
 print(r['file'],r.get('load',r.get('error')),r.get('metadata'),r.get('parameter_count'),r.get('nonzero'),r.get('previous_delta'))
 for n in ['empty','mid_X','late_O','terminal_draw']:
  if 'predictions' in r:
   q=r['predictions'][n];print(n,'policy',np.round(q['policy'],5),'wdl',np.round(q['wdl'],5),'v',round(q['scalar'],5))
